
import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to GentleWeave</h1>
      <p>Your go-to place for premium unstitched men's fabrics!</p>
    </div>
  );
}

export default App;
